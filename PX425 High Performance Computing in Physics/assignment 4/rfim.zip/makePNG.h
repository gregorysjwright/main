/*=========================================================/
/  makePNG header, PX425 2021 assignment 4.                /
/                                                          /
/  Original code created by N. Hine  - November 2021       /
/  (based on previous code by D. Quigley)                  /
/=========================================================*/
/* Function prototypes */
void writepng(char *filename, int **grid, int width, int height);
void bork(char *msg,...);
