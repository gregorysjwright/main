/*==================================================================/
/                     PX425 2021 Assignment 5                       /
/    Determining the Percolation Threshold for an ad-hoc Wireless   /
/    Network in a very large 3D model of a spherical space station  /
/                                                                   /
/                                                                   /
/===================================================================/
/  Starter code for optimisation and parallelisation                /
/  N. Hine, November 2021                                           /
/==================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <unistd.h>
#include <time.h>
#include "mt19937ar.h"
#include "mpi.h"

/* Add any additional header files needed for MPI, OpenMP etc. */

/* Typedefs */

/* variables for a "router", containing position & distance from center,
   router radius, and cluster number */
struct router {
  double x,y,z;
  double m,r;
  int cluster;
};

/* variables describing a domain decomposition of a volume filled with routers,
   containing sizes, number of cells, pointers to the routers in each cell,
   total number of routers, total number of clusters, and whether the
   clusters span the space */
struct cell_domain {
  double S, Lx, Ly, Lz;
  int nx, ny, nz, nc;
  struct router*** cell_rtr;
  int *cell_nrtr;
  int nrtr;
  int ncluster;
  int spanning_cluster;
  int run;
};

/* Function Prototypes */
int read_args(int argc, char **argv, double* R, double* S, double* D, int* N,
              double* P, double* Q, int* M, int* seedtime);
int isprint(int opt);
void find_cluster(int Nrtr, struct router** Rtr, int i);;
int connected(struct router* ra, struct router* rb);
int find_spanning_cluster(struct cell_domain* dom);
int merge_clusters(int nra, struct router** ra, int nrb, struct router** rb);
int count_clusters(struct cell_domain* dom);
void generate_local_domain(int* Nrtr, struct router** Rtr, int size, int rank,
                      double S,double R,double P, struct router*** left_bound, struct router*** right_bound, int* n_L_bound, int* n_R_bound);
void create_domain_decomp(struct cell_domain* dom, int Nrtr, struct router* Rtr,
                          int nx, int ny, int nz, int rank, int R, int n_L_halo, struct router* Lhalo);
void find_all_clusters(struct cell_domain* dom, int rank);
void destroy_domain_decomp(struct cell_domain* dom);
void initial_halo_communication(struct cell_domain* dom, struct router** left_bound, int n_L_bd, struct router** right_bound, int n_R_bd, struct router** left_halo, int* n_L_halo, struct router* right_halo, int* n_R_halo, int rank, int size, int Nrtr, double R);
void find_all_local_clusters_and_halo(struct cell_domain* dom, int rank, int size);
void compareHalosBoundaries(int* A, int* B, int n, int* C, int m);
void sendrecv_cluster_ids(struct cell_domain* dom,struct router** right_bound, struct router* Lhalo, int n_R_bd, int n_L_halo, int rank, int size, double P);


/* Main Routine */
/* Main Routine */
int main (int argc, char **argv)  {

  // MPI setup
  int rank, size;
  MPI_Init(&argc, &argv); //initialize MPI library
  MPI_Comm_size(MPI_COMM_WORLD, &size); //get number of processes
  MPI_Comm_rank(MPI_COMM_WORLD, &rank); //get my process id
  ///


  // Entire process clocks
  double start_t, end_t;

  start_t = MPI_Wtime();

  double R, S, Sinit, P, Pinit;
  int seedtime=0;

  /* Default Values */
  Sinit = 20; Pinit = 0.34; R = 1.0;
  int nP = 1; double deltaP = 0.015;
  int nS = 5; double deltaS = 5.0;
  int cellmin=8, cellmax=8;

  /* Read command line arguments */
  int ra = read_args(argc,argv,&R,&Sinit,&deltaS,&nS,&Pinit,&deltaP,&nP,
                     &seedtime);

  /* Echo command line arguments to stdout */
  if (!ra) {
    printf("# Command line arguments successfully processed\n");
  }
  if (ra) {
    printf("Error Processing command line arguments\n"); return EXIT_FAILURE;
  }

  /* Seed random number generator */
  unsigned long seed=20350292*(rank+1); // by default use a seed unique to each rank 
  if (seedtime) {
    seed = time(NULL);
    printf("# Using time-based random seed %ld\n",seed);
  }
  init_genrand(seed); // make sure unique later

  /* Loop variables */
  int i,j,iP,iS,irun;
  /* Router-related variables */
  int Nrtr=0;
  struct router* Rtr = NULL;
  /* Cell decomposition information */
  struct cell_domain dom;
  /* Number of runs for this invocation of the program */
  int nruns = nP*nS;


  // pointer to array of pointers locating the router arrays for the halo and boundary 
  struct router** left_bound = NULL;
  struct router** right_bound = NULL;
  struct router* Lhalo = NULL; // pointer to store the left and right halos
  struct router* Rhalo = NULL;

  // number of routers in boundary and halo
  int n_L_bound, n_R_bound; 
  int n_L_halo, n_R_halo;

  /* Loop over values of filling fraction P and system size S */
  for (irun=0;irun<nruns;irun++) {
    /* Find values of iP and iS for this run */
    iP = irun%nP;
    iS = (irun-iP)/nP;
    /* Find values of P and S for this run */
    P = Pinit + iP*deltaP; 
    S = Sinit + iS*deltaS;
    dom.S = S; dom.Lx = 2*S; dom.Ly = 2*S; dom.Lz = 2*S;   // could adjust to local domain for more efficiency,
    dom.run = irun;
    /* Generate randomly-placed routers in the domain */

    double t1,t2,t4,t5,t6,t7;
    t1 = MPI_Wtime();
    generate_local_domain(&Nrtr,&Rtr,size,rank,S,R,P,&left_bound, &right_bound, &n_L_bound, &n_R_bound);
    t2 = MPI_Wtime();
    
    int i = (int)(S/4/R); // no of cells per direction 
    if (i == 0) i = 1;
    

    // send/recv routers for halos
    initial_halo_communication(&dom, left_bound, n_L_bound, right_bound, n_R_bound, &Lhalo, &n_L_halo, Rhalo, &n_R_halo, rank, size,Nrtr, R);
    t4 = MPI_Wtime();
    // assign routers in local domain and halo to grid of cells
    create_domain_decomp(&dom,Nrtr,Rtr,i,i,i, rank, R, n_L_halo, Lhalo); 
    t5 = MPI_Wtime();
    /* Find clusters in cells, merge between cells, count clusters*/
    find_all_local_clusters_and_halo(&dom, rank, size);
    t6 = MPI_Wtime();

   
    for(i=0;i<(Nrtr);i++)
    {
      //printf("\n%d, %lf,%lf,%lf,%lf, cluster: %d", rank, (Rtr)[i].x,(Rtr)[i].y,(Rtr)[i].z, (Rtr)[i].m, (Rtr)[i].cluster);
    }

    for(i=0;i<(n_L_halo);i++)
    {
      //printf("\n%d, %lf,%lf,%lf,%lf, cluster: %d", rank, (Lhalo)[i].x,(Lhalo)[i].y,(Lhalo)[i].z, (Lhalo)[i].m, (Lhalo)[i].cluster);
    }

    // send boundary and halo cluster ids to process size-1. Compare halo/boundary ids so clusters share common set of ids. Determine whether a spanning cluster exists or not.
    sendrecv_cluster_ids(&dom,right_bound,Lhalo, n_R_bound, n_L_halo, rank, size, P);
    t7 = MPI_Wtime();
    
    if (rank == 0)
    {
      //printf("generate_local:%lf, init_halo:%lf, create_cells:%lf, local_clusters:%lf, finalee:%lf", t2-t1, t4-t2, t5-t4, t6-t5, t7-t6);
    }
    /* remove storage associated with domain decomposition and
        reset router cluster values */
    //printf("rank:%d before destroy\n", rank);
    destroy_domain_decomp(&dom);
    for (j=0;j<Nrtr;j++)
    {
        Rtr[j].cluster = 2*Nrtr*rank;
    }
    free(Rtr);
    free(left_bound); // free boundaries and halos
    free(right_bound);
    if(rank>0)
      free(Lhalo);
  }
 
  end_t = MPI_Wtime();

  printf("process %d time: %lf\n",rank,end_t-start_t);
    // end mpi
  MPI_Finalize(); //MPI cleanup
  ///

 
   return(EXIT_SUCCESS);

}


/* Set up number of routers for a given volume fraction, and
   generate random coordinates for each one, setting cluster
   value to 0 to indicate cluster not found yet */
void generate_local_domain(int* Nrtr, struct router** Rtr, int size, int rank,
                      double S,double R,double P, struct router*** left_bound, struct router*** right_bound, int* n_L_bound, int* n_R_bound)
{
  *Nrtr = (int)(S*S*S*P/(R*R*R)/(double)size); // local per shell
  *Rtr = malloc((*Nrtr)*sizeof(struct router));
  
  int i;
  double mag,x,y,z;
  double sx,sy,sz;
  double r,Rinn,Rout;
  
  r=S/pow(size,1.0/3.0);  // radius of inner sphere /core of global domain

  // inner and outer radii of local domain/shell
  Rinn = pow(rank,1.0/3.0)*r; 
  Rout = pow(rank+1,1.0/3.0)*r; 

  *(n_R_bound) = 0;
  double theta,thi;

  for (i=0;i<(*Nrtr);i++)
  {
    // Find random coordinates inside the shell
    //   whose centre is at (S,S,S) 

    mag = genrand()*(Rout-Rinn)+Rinn;
    theta = genrand()*2.0*M_PI;
    thi = genrand()*M_PI;
    x = mag*sin(thi)*cos(theta); y=mag*sin(thi)*sin(theta); z=mag*cos(thi);
    (*Rtr)[i].x = x+S; (*Rtr)[i].y = y+S;  (*Rtr)[i].z = z+S; (*Rtr)[i].m = mag;
    (*Rtr)[i].r = R; (*Rtr)[i].cluster = 2*(*Nrtr)*rank; // used as an offset for comparing ids from 2 local domains;
    if(mag>Rout-2.0*R){
    (*n_R_bound)++;
    }
      
  }
  
  
  *right_bound = malloc((*n_R_bound)*sizeof(struct router*));

  int j=0;
  for (i=0;i<(*Nrtr);i++)
    if((*Rtr)[i].m>Rout-2.0*R){
      (*right_bound)[j]=&((*Rtr)[i]); 
      j++;
    }

printf("\nrank: %d nrtr: %d n_rb: %d", rank, *Nrtr, *n_R_bound);
for(i=0;i<(*Nrtr);i++)
{
  //printf("\n%d, %lf,%lf,%lf,%lf", rank, (*Rtr)[i].x,(*Rtr)[i].y,(*Rtr)[i].z, (*Rtr)[i].m);
}

for(i=0;i<(*n_R_bound);i++)
{
  //printf("\n%d, %lf,%lf,%lf,%lf", rank, (*right_bound)[i]->x,(*right_bound)[i]->y,(*right_bound)[i]->z, (*right_bound)[i]->m);
}

}


void initial_halo_communication(struct cell_domain* dom, struct router** left_bound, int n_L_bd, struct router** right_bound, int n_R_bd, struct router** left_halo, int* n_L_halo, struct router* right_halo, int* n_R_halo, int rank, int size, int Nrtr, double R)
{

  // convert boundary routers into 1d array of 3d coordinates to easily send/recv
  double* right_b_coords; 

  right_b_coords = malloc(n_R_bd*sizeof(double)*3);
  
  int i;
  for(i=0;i<n_R_bd;i++)
  {
    right_b_coords[3*i] = (right_bound)[i]->x; // fix this
    right_b_coords[3*i+1] = (right_bound)[i]->y;
    right_b_coords[3*i+2] = (right_bound)[i]->z;   
  }
  
  
  double* left_H_buffer;
  MPI_Request request1, request2;

  if (size > 1) // more than 1 processor else dont bother.
  {
    *n_L_halo = 0;
    // send right boundary counts to left halo of rank+1 process , receive left halo from right boundary of rank+1 
    // note 6*dom->run + X is used to make each send/recv call unique for each run. Allows use of Isend. Could also use another communicator.
    if (rank==size-1)
      MPI_Recv(n_L_halo, 1, MPI_INT, rank-1, 6*dom->run+0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    else if (rank==0)
      MPI_Isend(&n_R_bd, 1, MPI_INT, rank+1,  6*dom->run+0,MPI_COMM_WORLD, &request1);
    else
      MPI_Sendrecv(&n_R_bd, 1, MPI_INT, rank+1,  6*dom->run+0, n_L_halo, 1, MPI_INT, rank-1,  6*dom->run+0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); // number of routers

    *left_halo = malloc((*n_L_halo)*sizeof(struct router));
    left_H_buffer = malloc((*n_L_halo)*sizeof(double)*3);
    
    
    // send/recv routers in boundary/halo to neighbours
    if (rank == 0)
      MPI_Isend(right_b_coords, n_R_bd*3, MPI_DOUBLE, rank+1, 6*dom->run+1, MPI_COMM_WORLD, &request2);
    else if (rank == size-1)
      MPI_Recv(left_H_buffer, (*n_L_halo)*3, MPI_DOUBLE, rank-1, 6*dom->run+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    else 
      MPI_Sendrecv(right_b_coords, n_R_bd*3, MPI_DOUBLE, rank+1, 6*dom->run+1, left_H_buffer, (*n_L_halo)*3, MPI_DOUBLE, rank-1, 6*dom->run+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

      for(i=0;i<(*n_L_halo);i++)
      {
        (*left_halo)[i].x = left_H_buffer[3*i];
        (*left_halo)[i].y = left_H_buffer[3*i+1];
        (*left_halo)[i].z = left_H_buffer[3*i+2];
        (*left_halo)[i].cluster = 2*Nrtr*rank;
        (*left_halo)[i].r = R;
      }
    
    if(rank>0)
      free(left_H_buffer);


    for(i=0;i<(*n_L_halo);i++)
    {
      //printf("\nNLH:%d %d, %lf,%lf,%lf", *n_L_halo, rank, (*left_halo)[i].x,(*left_halo)[i].y,(*left_halo)[i].z);
    }


  }
  
  
  free(right_b_coords);

}



/* Set up a cartesian grid of cells as a "domain decomposition" for helping
   find clusters of routers which span the space. Assign each router to
   a cell, and set up lists of pointers to the routers in each cell */
void create_domain_decomp(struct cell_domain* dom, int Nrtr, struct router* Rtr,
                          int nx, int ny, int nz, int rank, int R, int n_L_halo, struct router* Lhalo)
{
  
  dom->nx = nx; dom->ny = ny; dom->nz = nz;
  dom->nc = nx*ny*nz;
  dom->cell_nrtr = malloc(dom->nx * dom->ny * dom->nz * sizeof(int));
  dom->cell_rtr = malloc(dom->nx * dom->ny * dom->nz * sizeof(struct router*));
  dom->nrtr = Nrtr;
  dom->spanning_cluster = 0;
  
   


  // set counts of each cell's routers to zero 
  int ix, iy, iz, ic;
  for (ix=0;ix<dom->nx;ix++) {
    for (iy=0;iy<dom->ny;iy++) { 
      for (iz=0;iz<dom->nz;iz++) {
        ic = ix+dom->ny*iy+dom->ny*dom->nz*iz;
        dom->cell_nrtr[ic] = 0;
      }
    }
  }

  // count the routers associated with each cell
  int i;
  for (i=0;i<Nrtr;i++)
  {
    ix = floor(dom->nx * Rtr[i].x / dom->Lx);
    iy = floor(dom->ny * Rtr[i].y / dom->Ly);
    iz = floor(dom->nz * Rtr[i].z / dom->Lz);
    ic = ix+dom->ny*iy+dom->ny*dom->nz*iz;
    dom->cell_nrtr[ic]++;
  }
  for (i=0;i<n_L_halo;i++) // add the left halo routers to count
  {
    ix = floor(dom->nx * Lhalo[i].x / dom->Lx);
    iy = floor(dom->ny * Lhalo[i].y / dom->Ly);
    iz = floor(dom->nz * Lhalo[i].z / dom->Lz);
    ic = ix+dom->ny*iy+dom->ny*dom->nz*iz;
    dom->cell_nrtr[ic]++;
  }

  // allocate memory for storage of each cell's set of pointers to routers,
   //  then re-set the counts of numbers of routers to zero 
  for (ic=0;ic<dom->nc;ic++) {
    dom->cell_rtr[ic] = malloc(((dom->cell_nrtr)[ic])*sizeof(struct router*));  // allocates space for routers in halo also
    dom->cell_nrtr[ic] = 0;
  }
  // fill up the list of routers associated with each cell, counting them
   //  again as we go for indexing purposes 

  for (i=0;i<Nrtr;i++)
  {
    ix = floor(dom->nx * Rtr[i].x / dom->Lx);
    iy = floor(dom->ny * Rtr[i].y / dom->Ly);
    iz = floor(dom->nz * Rtr[i].z / dom->Lz);
    ic = ix+dom->ny*iy+dom->ny*dom->nz*iz;
    
    dom->cell_rtr[ic][dom->cell_nrtr[ic]] = &Rtr[i];
    dom->cell_nrtr[ic]++;
  }
    
  for (i=0;i<n_L_halo;i++) // add the left halo routers to count
  {
    ix = floor(dom->nx * Lhalo[i].x / dom->Lx);
    iy = floor(dom->ny * Lhalo[i].y / dom->Ly);
    iz = floor(dom->nz * Lhalo[i].z / dom->Lz);
    ic = ix+dom->ny*iy+dom->ny*dom->nz*iz;

    dom->cell_rtr[ic][dom->cell_nrtr[ic]] = &Lhalo[i];
    dom->cell_nrtr[ic]++;
  }


  //printf("rank:%d test5\n", rank);

}


/* deallocate storage associated with a domain decomposition struct */
void destroy_domain_decomp(struct cell_domain* dom)
{
  int ic;
  for (ic=0;ic<dom->nc;ic++) {
    free(dom->cell_rtr[ic]);
  }
  free(dom->cell_rtr);
  free(dom->cell_nrtr);
}

/* subroutine to identify all clusters in a domain decomposition structure */
void find_all_local_clusters_and_halo(struct cell_domain* dom, int rank, int size) // halo encapsulated already into cells
{

  int cl = 2*dom->nrtr*rank+1; // cluster id assigned so each id is unique to routers in the global and local domain.
  int ix,iy,iz,ic,i;
  
  /* loop over all cells of the domain decomposition, then loop over the routers
     in each cell. If cluster has not yet been identified, find all the 
     connected routers within this cell's list of routers (fast!) */
  for (ic=0;ic<dom->nc;ic++) {
    for (i=0;i<dom->cell_nrtr[ic];i++) {
      if (dom->cell_rtr[ic][i]->cluster==2*dom->nrtr*rank) {
        dom->cell_rtr[ic][i]->cluster = cl;
        find_cluster(dom->cell_nrtr[ic],dom->cell_rtr[ic],i);
        cl++;
      }
    }
  }


  /* merge clusters between cells if they are connected. Start from first
     cell and move outwards, checking the "outward" half of the set of nearest
     neighbour cells. Always retain lower numbered cluster to prevent circular
     "flows" of cluster value */
  int changed = 1;
  int icp, neighb;
  int dx,dy,dz;
  /* keep repeating loop until nothing changes any more */
  while(changed) {
    changed = 0;
    for (ic=0;ic<dom->nx*dom->ny*dom->nz;ic++) {
      /* loop over 13 of the 26 "nearest neighbour" cells on the cubic
         lattice, ie the outward half - otherwise double counting will
         occur and waste time */
      ix = ic%dom->nx;
      iy = ((ic-ix)/dom->nx)%dom->ny;
      iz = (ic-ix-dom->ny*iy)/(dom->nx*dom->ny);
      for (neighb=14;neighb<27;neighb++) {
        /* modulo arithmetic to find dx,dy,dz */
        dx = neighb%3 - 1;
        dy = ((neighb-dx)/3)%3 - 1;
        dz = (neighb-dx-3*dy)/9 - 1;
        /* prevent checking beyond limits of cell grid */
        if ((ix+dx>=dom->nx)||(iy+dy>=dom->ny)||(iz+dz>=dom->nz)) continue;
        if ((ix+dx<0)||(iy+dy<0)||(iz+dz<0)) continue;
        /* find index of neighbour cell */
        icp = ic + dx + dom->ny*dy + dom->ny*dom->nz*dz;
        changed = changed + merge_clusters(dom->cell_nrtr[ic],
            dom->cell_rtr[ic], dom->cell_nrtr[icp], dom->cell_rtr[icp]);
      }
      
    }
  }

  if (size == 1)
  {
    dom->ncluster = count_clusters(dom);
    dom->spanning_cluster = find_spanning_cluster(dom);
  }

}








/* recursive subroutine that finds all the "connected" routers in a list,
   starting from a specific router i, and sets their cluster value to
   match that of the starting router */ 
void find_cluster(int Nrtr, struct router** Rtr, int i)
{
  int j;
  for (j=0;j<Nrtr;j++)
  {
    if (connected(Rtr[i],Rtr[j])&&(Rtr[j]->cluster!=Rtr[i]->cluster))
    {
      Rtr[j]->cluster = Rtr[i]->cluster;
      find_cluster(Nrtr,Rtr,j);
    }
  }
}

/* function to check if two routers are "connected", ie their separation is
   less than the sum of their radii */
int connected(struct router* ra, struct router* rb)
{
   if ((ra->x-rb->x)*(ra->x-rb->x) + 
       (ra->y-rb->y)*(ra->y-rb->y) +
       (ra->z-rb->z)*(ra->z-rb->z) <= (ra->r+rb->r)*(ra->r+rb->r))
   { return 1;}
   else
   { return 0;}
}

/* function to merge the clusters associated with two lists of routers if
   pairs of them are closer than the sum of their radii. Retains lower-
   numbered cluster and converts higher-numbered cluster to match */
int merge_clusters(int nra, struct router** ra, int nrb, struct router** rb)
{
  int i,j,k,cl,changed;
  changed = 0;
  /* Loop over routers i, j in the two cells */
  for (i=0;i<nra;i++) {
    for (j=0;j<nrb;j++) {
      /* search for pairs of routers whose cluster values are not equal */
      if (ra[i]->cluster!=rb[j]->cluster) {
        /* if they are closer than the sum of their radii ...*/
        if (connected(ra[i],rb[j])) {
          /* convert whichever cluster has the higher index to match the
             lower index */
          if (rb[j]->cluster > ra[i]->cluster) {
             /* cluster in cell A has lower index */
            cl = rb[j]->cluster;
            for (k=0;k<nrb;k++) {
              if (rb[k]->cluster==cl) {
                rb[k]->cluster = ra[i]->cluster;
              }
            }
          }  /* else cluster in cell B has lower index */
          else {
            cl = ra[i]->cluster;
            for (k=0;k<nra;k++) {
              if (ra[k]->cluster==cl) {
                ra[k]->cluster = rb[j]->cluster;
              }
            }
          }
          /* set flag to remember that something changed within this call so
             that we can halt merging once nothing changes any more */
          changed = 1;
        }
      }
    }
  }
  return changed;
}

/* Count the number of unique clusters in the list of routers */
int count_clusters(struct cell_domain* dom)
{
  int count, found;
  int* counted = malloc(dom->nrtr*sizeof(int));
  int ic,i,j;
  count = 0;
  for (ic=0;ic<dom->nc;ic++) {
    for (i=0;i<dom->cell_nrtr[ic];i++) {
      found = 0;
      /* check if we have already counted this cluster */
      for (j=0;j<count;j++) {
        if (dom->cell_rtr[ic][i]->cluster==counted[j]) {
          found = 1;
          break;
        }
      }
      /* if not, add it to the list and increment the count */
      if (!found) {
        counted[count] = dom->cell_rtr[ic][i]->cluster;
        count++;
      }
    }
  }
  free(counted);
  return count;
}

/* check if there are clusters extending to the surface in each octant */
int find_spanning_cluster(struct cell_domain* dom)
{
  int* octant_check_list[8];
 
  int ioct,ic,cl,i,icl,jcl;
  int spanning_cluster = 0;
  double x,y,z,r,m;

  /* Set up and initialise storage for finding spanning cluster */
  for (ioct=0;ioct<8;ioct++) {
    octant_check_list[ioct] = malloc(dom->ncluster*sizeof(int));
    for (i=0;i<dom->ncluster;i++) {
       octant_check_list[ioct][i] = -1;
    }
  }

  /* Loop over cells */
  for (ic=0;ic<dom->nc;ic++) {
     /* Loop over routers in each cell */
     for (i=0;i<dom->cell_nrtr[ic];i++) {
        x = dom->cell_rtr[ic][i]->x;
        y = dom->cell_rtr[ic][i]->y;
        z = dom->cell_rtr[ic][i]->z;
        m = dom->cell_rtr[ic][i]->m;
        r = dom->cell_rtr[ic][i]->r;
        cl = dom->cell_rtr[ic][i]->cluster;
        /* If router touches the sphere edge... */
        if (m+r>dom->S) {
           ioct = 0;
           /* Calculate which octant router is in */
           if (x>dom->S) ioct++;
           if (y>dom->S) ioct+=2;
           if (z>dom->S) ioct+=4;
           jcl = 0;
           /* Check if this cluster has been found for this octant */
           for(icl=0;icl<dom->ncluster;icl++) {
              /* If we reach the end of the list of clusters, add this one at 
                 the end and stop looking */
              if (octant_check_list[ioct][icl]==-1) {
                 octant_check_list[ioct][icl] = cl;
                 jcl = 1;
                 break;
              }
              /* If this cluster has already been listed, stop looking */
              if (octant_check_list[ioct][icl] == cl) {break;}
           }
        }
     }
  }
  int sum;
  /* Check if the same cluster appears in all 8 lists */
  for (icl=0;icl<dom->ncluster;icl++) {
     sum = 0;
     /* Get next cluster from octant 0, quit if blank */
     cl = octant_check_list[0][icl];
     if (cl==-1) break;
     /* Check all 8 octants to check this cluster appears in each */
     for (ioct=0;ioct<8;ioct++) {
        for (jcl=0;jcl<dom->ncluster;jcl++) {
           if (octant_check_list[ioct][jcl]==cl) {
              sum++;
              break;
           }
        }
     } 
     if (sum==8) { spanning_cluster++;} 
  }
  /* Free storage associated with spanning cluster check */
  for (ioct=0;ioct<8;ioct++) {
    free(octant_check_list[ioct]);
  }
  return spanning_cluster;
}

/* Parse Command line arguments */
int read_args(int argc, char **argv, double* R, double* S, double* D, int* N,
              double* P, double* Q, int* M, int* seedtime)
{
  int index;
  int c;
  opterr = 0;

  /* Process all flags found in argc */
  while ((c = getopt(argc, argv, "R:S:D:N:P:Q:M:ts")) != -1)
    switch (c)
      {
      case 't':
        *seedtime = 1;
        break;
      case 'R':
        *R = atof(optarg);
        if (*R<=0.0) {
           opterr = 1; 
           fprintf (stderr, "Radius argument could not be read: %s\n", optarg);
        }
        break;
      case 'S':
        *S = atof(optarg);
        if (*S<=0.0) {
           opterr = 1; 
           fprintf (stderr, "Station size argument could not be read: %s\n", optarg);
        }
        break;
      case 'P':
        *P = atof(optarg);
        if (*P<=0.0) {
           opterr = 1; 
           fprintf (stderr, "Volume fraction argument could not be read: %s\n", optarg);
        }
        break;
      case 'D':
        *D = atof(optarg);
        if (*D<0.0) {
           opterr = 1; 
           fprintf (stderr, "Station size step argument could not be read: %s\n", optarg);
        }
        break;
      case 'Q':
        *Q = atof(optarg);
        if (*Q<0.0) {
           opterr = 1; 
           fprintf (stderr, "Volume fraction step argument could not be read: %s\n", optarg);
        }
        break;
      case 'N':
        *N = atoi(optarg);
        if (*N<=0.0) {
           opterr = 1; 
           fprintf (stderr, "Number of station size steps argument could not be read: %s\n", optarg);
        }
        break;
      case 'M':
        *M = atof(optarg);
        if (*M<=0.0) {
           opterr = 1; 
           fprintf (stderr, "Number of volume fraction steps argument could not be read: %s\n", optarg);
        }
        break;
      case '?':
        if ((optopt == 'R')||(optopt=='P')||(optopt=='S'))
          fprintf (stderr, "Option -%c requires an argument.\n", optopt);
        else if (isprint(optopt))
          fprintf (stderr, "Unknown option `-%c'.\n", optopt);
        else
          fprintf (stderr,"Unknown option character `\\x%x'.\n",optopt);
        return 1;
      default:
        abort ();
      }

  /* List unrecognised arguments */
  for (index = optind; index < argc; index++)
    printf ("Non-option argument %s\n", argv[index]);

  return opterr;
}

// Merges ids for each local domain
void sendrecv_cluster_ids(struct cell_domain* dom, struct router** right_bound, struct router* Lhalo, int n_R_bd, int n_L_halo, int rank, int size, double P)
{
  int i;
  int* right_bound_clsts; // ids for clusters 
  int* left_halo_clsts;
  right_bound_clsts = malloc(sizeof(int)*(n_R_bd));
  left_halo_clsts = malloc(sizeof(int)*(n_L_halo));

  // store arrays of cluster ids
  for(i=0;i<n_R_bd;i++)
  {
    right_bound_clsts[i]=right_bound[i]->cluster;
  }
  for(i=0;i<n_L_halo;i++)
  {
    left_halo_clsts[i]=Lhalo[i].cluster;
  }
  

  int* n_bh; // number of routers in boundary/halo of all processes
  n_bh = malloc(sizeof(int)*size*2);
  int** rbs; // to store every cluster id from all processes.
  int** lhs;
  rbs=malloc(sizeof(int*)*size);
  lhs=malloc(sizeof(int*)*size);


  int* tempRB;
  int* tempLH;

  MPI_Request count_request;


  // send/recv number of routers in boundary/halo to process size-1. Then use these in malloc
  // As with elsewhere, could have considered using the status in the MPI_Recv call instead. 
  if (rank!=size-1)
  {
    int n[2];
    n[0] = n_L_halo; 
    n[1] = n_R_bd;
    MPI_Isend(n, 2, MPI_INT, size-1, 6*dom->run+2, MPI_COMM_WORLD, &count_request);
   
  }
  else
  {
    int i;
    for(i=0;i<size-1;i++)
    {
      MPI_Recv(&(n_bh[2*i]), 2, MPI_INT, i, 6*dom->run+2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    } 
  } 

  MPI_Request right_request;
  MPI_Request left_request;
  // send boundary/halo routers to size-1
  if (rank != size-1)
    MPI_Isend(right_bound_clsts, n_R_bd, MPI_INT, size-1, 6*dom->run+3, MPI_COMM_WORLD, &right_request);
  if (rank!=0 && rank!=size-1)
    MPI_Isend(left_halo_clsts, n_L_halo, MPI_INT, size-1, 6*dom->run+4, MPI_COMM_WORLD, &left_request);

  // serial part
  if (rank== size-1)
  {

    double t1,t2,t3,t4;
    t1 = MPI_Wtime();

    // allocate memory for boundary/halo data of routers from all processes
    int i; 
    for (int i=0;i<size-1;i++)
    {
    lhs[i] = malloc(sizeof(int)*n_bh[2*i]);
    rbs[i] = malloc(sizeof(int)*n_bh[2*i+1]);
    }
    // assign own halo/boundary data to array
    n_bh[2*(size-1)] = n_L_halo;
    n_bh[2*(size-1)+1] = n_R_bd;
    rbs[size-1] = right_bound_clsts;
    lhs[size-1] = left_halo_clsts;
    //printf("0's LH:%d, RB:%d", n_bh[0], n_bh[1]);
    int s;
    // recv routers from all other processes
    for(i=0;i<size-1;i++)
    {
      MPI_Recv(rbs[i], n_bh[2*i+1], MPI_INT, i, 6*dom->run+3, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      if(i!=0)
        MPI_Recv(lhs[i], n_bh[2*i], MPI_INT, i, 6*dom->run+4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    } 

    for(i=0;i<size;i++)
    {
      for(s=0;s<n_bh[2*i+1];s++)
      {
        //printf("\nrank:%d, (RB)cluster:%d",i,rbs[i][s]);
      }
      for(s=0;s<n_bh[2*i];s++)
      {
        //printf("\nrank:%d, (LH)cluster:%d",i,lhs[i][s]);
      }
   
    }


    //int s;
    for(s=0;s<size-1;s++)
     // for(i=0;i<10;i++)
      //{printf("\nN_LH:%d N_RH:%d", n_bh[2*s], n_bh[2*s+1]);}
      for(i=0;i<(1);i++)
      {
        //printf("\nrank: %d rb:%d lh:%d", rank,(rbs[s])[i],(lhs[s])[i]);
      }

    // Sequentially updates the ids of the boundary/halo ids for the same routers. The new routers ids are then sent to the next right boundary. The process is repeated till the ids are updated for the outer most shell boundary. 
    t2 = MPI_Wtime();
    for(i=0;i<size-1;i++)
    {
      compareHalosBoundaries(rbs[i], lhs[i+1], n_bh[2*i+2], rbs[i+1], n_bh[2*i+3]); // changed
    }

    for(i=0;i<size;i++)
    {
      for(s=0;s<n_bh[2*i+1];s++)
      {
        //printf("\nrank:%d, (RB)cluster:%d",i,rbs[i][s]);
      }
      for(s=0;s<n_bh[2*i];s++)
      {
        //printf("\nrank:%d, (LH)cluster:%d",i,lhs[i][s]);
      }
   
    }

    t3 = MPI_Wtime();
    int k,j, oct, count;

    // calculates whether there is a spanning cluster in the right boundary of the outer most shell
    for(i=0;i<n_R_bd;i++)
    {
      // for every router check their cluster id, look at every router with same id 8 times (once for each octant). If there is a router in every octant with same id then cluster spans.
      if (right_bound[i]->m>dom->S-right_bound[i]->r) // checks if router is 'touching' the surface of the global domain
      {
        count=0;
        for(j=0;j<8;j++) // loops for every octant
        {
          
          for(k=0; k<n_R_bd;k++)
          {
            oct=0;
            if (rbs[size-1][k]!=rbs[size-1][i]) continue; // checks ids of routers are equal
            if (right_bound[k]->m>dom->S-right_bound[k]->r) continue; // checks if router is 'touching' surface
            // get octant of router
            if (right_bound[k]->x>dom->S) oct++;
            if (right_bound[k]->y>dom->S) oct+=2;
            if (right_bound[k]->z>dom->S) oct+=4;
            //printf("\n%d\n", oct);
            if (oct==j)
            {
              count++;
              break;
            }
          }
        }
        if(count==8) break; // spans cluster
      }                
    }
    t4 = MPI_Wtime();     

    printf("\nS = %f P = %f: ", dom->S, P);
    if(count==8)printf("spanning found!");
    else printf("fail");

    // tests
    /*
    int R1[21] = {1,1,2,2,20,20,3,4,4,5,6,7,8,9,10,11,11,12,12,13,14};
    int L2[21] = {1,1,2,2,2,2,3,4,5,6,6,7,9,9,9,10,11,11,12,13,13};  
    int R2[15] = {1,1,3,3,4,5,6,6,8,8,9,10,12,13,13};


    for(i=0;i<21;i++)
    {
      L2[i]+=30;
    }
    for(i=0;i<15;i++)
    {
      R2[i]+=30;
    }


    compareHalosBoundaries(R1,L2,21,R2,15);
    for(i=0;i<15;i++)
    {
      printf(" %d ", R2[i]);
    }
    */

    //printf("\nrecieve time:%lf compare time:%lf Spanning time:%lf", t2-t1, t3-t2, t4-t3);
    for(int i=0;i<size;i++)
    { 
      free(lhs[i]);
      free(rbs[i]);
    }
  }
      
  free(lhs);
  free(rbs);


}

void compareHalosBoundaries(int* A, int* B, int n, int* C, int m) // compare arrays of inner halo (B) to outer boundary (A) cluster ids of previous rank. If the cluster ids of the halo changes, copy the mapping to the outer boundary (C) of this rank    
{
  int i,j,temp;
  // for each cluster id of the routers
  for(i=0;i<n;i++)
  {
    if (A[i] > B[i]) // update the id to the larger one
    {
      temp=B[i];
      B[i] = A[i];
      for (j=0;j<n;j++)
      {
        if (B[j] == temp) 
          B[j] = A[i];
        if (A[j] == temp)
          A[j] = B[i];
      }
      for (j=0;j<m;j++) // update to new ids for all routers in (C)
        if (C[j] == temp)
          C[j] = A[i];

    }
    else if (A[i] < B[i])
    {
      temp=A[i];
      A[i] = B[i];
      for (j=0;j<n;j++)
      {
        if (A[j] == temp)       
          A[j] = B[i];
        if (B[j] == temp)
          B[j] = A[i];
      }
      for (j=0;j<m;j++)
        if (C[j] == temp)
          C[j] = B[i];

      
    }
  }
}
